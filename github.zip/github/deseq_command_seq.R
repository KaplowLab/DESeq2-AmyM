if (!requireNamespace("BiocManager", quietly = TRUE)) {
  install.packages("BiocManager")
}
BiocManager::install("DESeq2")
install.packages("dplyr")


library(DESeq2)
library(dplyr)

count_data <- read.csv("C:/Temp/Kaplow/code/data/ORF_complete_RNAseq_validation(in).csv", row.names = 1)
head(count_data)

sample_info <- data.frame(
  row.names = colnames(count_data),
  condition = c("Ascl2","Ascl2","Ascl2",
                "Esrrb","Esrrb","Esrrb",
                "Esrrg","Esrrg","Esrrg",
                "Foxa3","Foxa3",
                "Gata4","Gata4","Gata4",
                "Gfp","Gfp","Gfp","Gfp","Gfp","Gfp",
                "Gsc2","Gsc2","Gsc2",
                "HNF4G","HNF4G","HNF4G",
                "KLF6","KLF6","KLF6",
                "mCherry","mCherry","mCherry",
                "Nr5a","Nr5a","Nr5a",
                "Nfib","NfibNfib",
                "NHLH1","NHLH1","NHLH1",
                "NHLH2","NHLH2","NHLH2",
                "NR5A2","NR5A2","NR5A2",
                "Sall4","Sall4","Sall4",
                "SMAD2","SMAD2","SMAD2",
                "SMAD3","SMAD3","SMAD3",
                "SMARCA2","SMARCA2","SMARCA2",
                "Sox17","Sox17","Sox17",
                "TCF7","TCF7","TCF7",
                "Tfec","Tfec","Tfec",
                "Zic4","Zic4","Zic4",
                "Znf398","Znf398","Znf398",
                "HNF4A","HNF4A","HNF4A",
                "KLF7","KLF7","KLF7",
                "FOXA2","FOXA2","FOXA2",
                "PPARG","PPARG","PPARG",
                "GFP","GFP","GFP",
                "NovaPHH","NovaPHH","NovaPHH",
                "PHH","PHH","PHH"))

dds <- DESeqDataSetFromMatrix(
  countData = count_data,
  colData   = sample_info,
  design    = ~ condition
)

# this part is slow
dds <- DESeq(dds)
  

res <- results(dds)

# turn into dataframe for easier subset
res_df <- as.data.frame(res)

# filter
res_filtered <- subset(
  res_df,
  padj < 0.05 & abs(log2FoldChange) >= 1
)

# verify
head(res_filtered)

# save to file
write.csv(res_filtered, "filtered_DESeq2_results.csv", row.names = TRUE)

# find avgs
avg_res <- res_filtered %>%
  summarise(mean_log2fc = mean(log2FoldChange, na.rm=TRUE),
            sd_log2fc   = sd(log2FoldChange, na.rm=TRUE))

# ma plot
plot(res_filtered$baseMean, res_filtered$log2FoldChange,
     log="x", pch=20, main="MA Plot",
     xlab="Mean expression (log scale)", ylab="Log2 fold change")
abline(h = c(-1, 1), col="red", lty=2)  # fold-change thresholds

# volcano plot
with(res_filtered, plot(log2FoldChange, -log10(padj),
                        pch=20, main="Volcano Plot",
                        xlab="Log2 fold change",
                        ylab="-log10(p-value)"))
abline(v=c(-1,1), h=-log10(0.05), col="red", lty=2)
